const SKILLS = [
  { id: 1, name: 'Python' },
  { id: 2, name: 'SQL' },
  { id: 3, name: 'Java' },
  { id: 4, name: 'Power BI' },
  { id: 5, name: 'Tableau' },
  { id: 6, name: 'Excel' },
  { id: 7, name: 'Machine Learning' },
  { id: 8, name: 'HTML' },
  { id: 9, name: 'CSS' },
  { id: 10, name: 'JavaScript' }
];

function showToast(message) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.textContent = message;
  toast.classList.add('visible');
  setTimeout(() => toast.classList.remove('visible'), 2600);
}

function setFieldError(fieldEl, hasError) {
  fieldEl.classList.toggle('has-error', hasError);
}

// TODO: point this at your real backend once it exists, e.g.
// fetch('/api/students', { method: 'POST', body: JSON.stringify(payload), headers: {'Content-Type':'application/json'} })
async function mockSave(payload) {
  await new Promise(resolve => setTimeout(resolve, 500));
  console.log('Saved payload (mock — no backend connected yet):', payload);
  return { ok: true };
}

// ---------- PROFILE PAGE ----------
const profileForm = document.getElementById('profile-form');
if (profileForm) {
  const skillsContainer = document.getElementById('skills-container');
  const addSkillBtn = document.getElementById('add-skill-btn');
  let skillRowCount = 0;

  function skillOptionsHTML(selectedId) {
    return SKILLS.map(s =>
      `<option value="${s.id}" ${String(s.id) === String(selectedId) ? 'selected' : ''}>${s.name}</option>`
    ).join('');
  }

  function addSkillRow() {
    skillRowCount++;
    const row = document.createElement('div');
    row.className = 'skill-row';
    row.innerHTML = `
      <select name="skill_id" aria-label="Skill">
        <option value="">Select skill</option>
        ${skillOptionsHTML('')}
      </select>
      <select name="skill_level" aria-label="Skill level">
        <option value="Beginner">Beginner</option>
        <option value="Intermediate">Intermediate</option>
        <option value="Advanced">Advanced</option>
      </select>
      <button type="button" class="icon-btn" title="Remove skill">&times;</button>
    `;
    row.querySelector('.icon-btn').addEventListener('click', () => row.remove());
    skillsContainer.appendChild(row);
  }

  addSkillBtn.addEventListener('click', addSkillRow);
  addSkillRow();

  document.getElementById('reset-btn').addEventListener('click', () => {
    profileForm.reset();
    skillsContainer.innerHTML = '';
    addSkillRow();
    document.querySelectorAll('.field').forEach(f => setFieldError(f, false));
  });

  profileForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const requiredFields = [
      { id: 'register_no', check: v => v.trim().length > 0 },
      { id: 'department_id', check: v => v !== '' },
      { id: 'first_name', check: v => v.trim().length > 0 },
      { id: 'last_name', check: v => v.trim().length > 0 },
      { id: 'email', check: v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) }
    ];

    let hasError = false;
    requiredFields.forEach(({ id, check }) => {
      const input = document.getElementById(id);
      const fieldEl = input.closest('.field');
      const valid = check(input.value);
      setFieldError(fieldEl, !valid);
      if (!valid) hasError = true;
    });

    if (hasError) {
      showToast('Please fix the highlighted fields.');
      return;
    }

    const formData = new FormData(profileForm);
    const payload = {
      register_no: formData.get('register_no'),
      department_id: formData.get('department_id'),
      first_name: formData.get('first_name'),
      last_name: formData.get('last_name'),
      gender: formData.get('gender'),
      dob: formData.get('dob'),
      email: formData.get('email'),
      phone: formData.get('phone'),
      cgpa: formData.get('cgpa'),
      attendance: formData.get('attendance'),
      linkedin: formData.get('linkedin'),
      github: formData.get('github'),
      portfolio: formData.get('portfolio'),
      skills: Array.from(skillsContainer.querySelectorAll('.skill-row')).map(row => ({
        skill_id: row.querySelector('[name="skill_id"]').value,
        skill_level: row.querySelector('[name="skill_level"]').value
      })).filter(s => s.skill_id)
    };

    const submitBtn = profileForm.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.textContent = 'Saving...';
    await mockSave(payload);
    submitBtn.disabled = false;
    submitBtn.textContent = 'Save profile';
    showToast('Profile saved.');
  });
}

// ---------- RESUME PAGE ----------
const uploadZone = document.getElementById('upload-zone');
if (uploadZone) {
  const fileInput = document.getElementById('resume-file-input');
  const fileChip = document.getElementById('file-chip');
  const fileChipName = document.getElementById('file-chip-name');
  const fileChipRemove = document.getElementById('file-chip-remove');
  const fileError = document.getElementById('file-error');
  const scorePanel = document.getElementById('score-panel');
  const scoreRing = document.getElementById('score-ring');
  const scoreNote = document.getElementById('score-note');
  const saveBtn = document.getElementById('save-resume-btn');
  const clearBtn = document.getElementById('clear-btn');

  let selectedFile = null;
  const MAX_SIZE = 5 * 1024 * 1024;
  const ALLOWED = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];

  function resetUpload() {
    selectedFile = null;
    fileInput.value = '';
    fileChip.classList.remove('visible');
    scorePanel.classList.remove('visible');
    fileError.style.display = 'none';
  }

  function handleFile(file) {
    if (!file) return;
    const extOk = /\.(pdf|doc|docx)$/i.test(file.name);
    if (!extOk || file.size > MAX_SIZE) {
      fileError.textContent = !extOk
        ? 'Only PDF, DOC, or DOCX files are supported.'
        : 'File is larger than 5 MB.';
      fileError.style.display = 'block';
      resetUpload();
      return;
    }
    fileError.style.display = 'none';
    selectedFile = file;
    fileChipName.textContent = file.name;
    fileChip.classList.add('visible');
    scorePanel.classList.remove('visible');
  }

  uploadZone.addEventListener('click', () => fileInput.click());
  uploadZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadZone.classList.add('drag-over');
  });
  uploadZone.addEventListener('dragleave', () => uploadZone.classList.remove('drag-over'));
  uploadZone.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadZone.classList.remove('drag-over');
    if (e.dataTransfer.files.length) handleFile(e.dataTransfer.files[0]);
  });
  fileInput.addEventListener('change', () => handleFile(fileInput.files[0]));
  fileChipRemove.addEventListener('click', resetUpload);
  clearBtn.addEventListener('click', resetUpload);

  saveBtn.addEventListener('click', async () => {
    if (!selectedFile) {
      fileError.textContent = 'Choose a resume file before saving.';
      fileError.style.display = 'block';
      return;
    }
    fileError.style.display = 'none';
    saveBtn.disabled = true;
    saveBtn.textContent = 'Uploading...';

    // TODO: replace with a real upload, e.g.
    // const fd = new FormData(); fd.append('resume', selectedFile);
    // await fetch('/api/resumes', { method: 'POST', body: fd });
    await mockSave({ file_name: selectedFile.name, file_size: selectedFile.size });

    // Placeholder score until a real ATS-scoring backend is connected.
    const mockScore = Math.floor(Math.random() * 21) + 70;
    scoreRing.textContent = mockScore;
    scoreNote.textContent = 'This is a placeholder score. Connect the backend to generate a real one.';
    scorePanel.classList.add('visible');

    saveBtn.disabled = false;
    saveBtn.textContent = 'Save resume';
    showToast('Resume uploaded.');
  });
}
